IP_receive = '134.130.169.12'
Port_send = 12334
Port_receive = 12334

NumData = 18

fiware_service = "grid_uc"
device_type = "RTDS"
device_id = "rtds001"

cloud_ip = "10.12.0.10"
broker_ip = cloud_ip
port = 1883
api_key = "asd1234rtds"