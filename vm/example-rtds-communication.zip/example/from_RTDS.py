import numpy as np
import paho.mqtt.client as paho
import time

# import own RPI2 scripts
from receive import receive
from settings import *


def on_publish_func(client, userdata, result):  # create function for callback
    """
    client, userdata, result not necessary in this particular example but might be useful if you need to distinguish
    between different entites.
    """
    print("Data published! \n")
    pass


def storedata_attempt():

    # receive from RTDS:
    npdata = np.array(receive(IP_receive, Port_receive, NumData))
    print("Values received from RTDS: ", npdata)

    # build the payload for MQTT message
    test_payload = "your payload with the values: " + str(npdata)

    # publish to the cloud:
    client1 = paho.Client("control1")
    client1.on_publish = on_publish_func
    client1.connect(broker_ip, port)
    client1.publish("/" + api_key + "/" + device_id + "/attrs", test_payload)


def storedata_once():
    while True:
        try:
            storedata_attempt()
        except:
            print("Unexpected error:", sys.exc_info())
            # logging.error(" When: " + str(datetime.now()) + " --- " + "Error in storedataOnce(): ", sys.exc_info())
            pass
        else:
            break


def storedata_repeatedly():
    while True:
        storedata_once()
        time.sleep(0.1)


storedata_repeatedly()
